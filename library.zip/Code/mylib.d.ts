/* tslint:disable */
/* eslint-disable */
/**
* @param {Int16Array} arr
*/
export function bubble_sort(arr: Int16Array): void;
/**
* @param {Int16Array} d
*/
export function insertion_sort(d: Int16Array): void;
/**
* @param {Int16Array} d
*/
export function quicksort(d: Int16Array): void;
/**
* @param {Int16Array} d
*/
export function parallel_quicksort(d: Int16Array): void;
/**
* @param {Int16Array} arr
*/
export function mergesort(arr: Int16Array): void;
/**
* @param {Int16Array} arr
*/
export function selection_sort(arr: Int16Array): void;
/**
* @param {Int16Array} arr
*/
export function parallel_merge_sort(arr: Int16Array): void;
/**
* @param {number} num_threads
* @returns {Promise<any>}
*/
export function initThreadPool(num_threads: number): Promise<any>;
/**
* @param {number} receiver
*/
export function wbg_rayon_start_worker(receiver: number): void;
/**
*/
export class wbg_rayon_PoolBuilder {
  free(): void;
/**
* @returns {number}
*/
  numThreads(): number;
/**
* @returns {number}
*/
  receiver(): number;
/**
*/
  build(): void;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly bubble_sort: (a: number, b: number) => void;
  readonly insertion_sort: (a: number, b: number) => void;
  readonly quicksort: (a: number, b: number) => void;
  readonly parallel_quicksort: (a: number, b: number) => void;
  readonly mergesort: (a: number, b: number) => void;
  readonly selection_sort: (a: number, b: number) => void;
  readonly parallel_merge_sort: (a: number, b: number) => void;
  readonly __wbg_wbg_rayon_poolbuilder_free: (a: number) => void;
  readonly wbg_rayon_poolbuilder_numThreads: (a: number) => number;
  readonly wbg_rayon_poolbuilder_receiver: (a: number) => number;
  readonly wbg_rayon_poolbuilder_build: (a: number) => void;
  readonly initThreadPool: (a: number) => number;
  readonly wbg_rayon_start_worker: (a: number) => void;
  readonly memory: WebAssembly.Memory;
  readonly __wbindgen_malloc: (a: number) => number;
  readonly __wbindgen_free: (a: number, b: number) => void;
  readonly __wbindgen_start: () => void;
}

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {InitInput | Promise<InitInput>} module_or_path
* @param {WebAssembly.Memory} maybe_memory
*
* @returns {Promise<InitOutput>}
*/
export default function init (module_or_path?: InitInput | Promise<InitInput>, maybe_memory?: WebAssembly.Memory): Promise<InitOutput>;
