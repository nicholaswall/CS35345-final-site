let currentSort: Sort = "quicksort";
const ALL_SORTS = [
  "quicksort",
  "parallel quicksort",
  "merge sort",
  "parallel merge sort",
  "bubble sort",
  "insertion sort",
  "selection sort",
] as const;
type SortTuple = typeof ALL_SORTS;
type Sort = SortTuple[number];

let statusElem;
const setStatusRunningEvent = new Event("setStatusRunning");
const setStatusFinishedEvent = new Event("setStatusFinished");
let timer;
const setTimerEvent = new Event("setTimer");
let time;
let mainWorker;
let button;
let sort_counts = [10_000, 50_000, 100_000, 150_000];
let sort_count = sort_counts[0];

function createButton(text: string, id: string) {
  const element = document.createElement("button");
  element.value = text;
  element.id = id;
  element.innerText = text;

  return element;
}

function setSort(sort: Sort) {
  currentSort = sort;
  console.log("Current sort has been set to:", currentSort);
}

function getCurrentSort() {
  return currentSort;
}

function setupDocument() {
  document.body.appendChild(createButton("Test algorithm", "multiThread"));
  button = document.getElementById("multiThread");

  let st = document.createElement("p");
  st.innerHTML = "Status: Waiting";
  st.addEventListener("setStatusRunning", () => {
    st.innerHTML = "Status: Running";
  });
  st.addEventListener("setStatusFinished", () => {
    st.innerHTML = "Status: Finished";
  });
  document.body.appendChild(st);
  statusElem = st;

  let timr = document.createElement("p");
  timr.innerHTML = "No time to display";
  timr.addEventListener("setTimer", () => {
    timr.innerHTML = "Run took: " + time + " milliseconds.";
  });
  timer = timr;
  document.body.appendChild(timr);

  let dropDown = document.createElement("select");
  dropDown.id = "sortlist";
  document.body.appendChild(dropDown);

  for (var i = 0; i < ALL_SORTS.length; i++) {
    var option = document.createElement("option");
    option.value = ALL_SORTS[i];
    option.text = ALL_SORTS[i];
    dropDown.appendChild(option);
  }

  dropDown.onchange = function () {
    //@ts-expect-error
    setSort(this.options[this.selectedIndex].value);
  };

  let sortCountDropDown = document.createElement("select");
  sortCountDropDown.id = "sort_count";
  document.body.appendChild(sortCountDropDown);

  for (var i = 0; i < sort_counts.length; i++) {
    var option = document.createElement("option");
    option.value = sort_counts[i].toString();
    option.text = sort_counts[i].toString();
    sortCountDropDown.appendChild(option);
  }

  sortCountDropDown.onchange = function () {
    //@ts-expect-error
    sort_count = parseInt(this.options[this.selectedIndex].value);
  };
}

function mainWorkerFunction() {}

async function myMain() {
  setupDocument();
  mainWorkerFunction();
  mainWorker = new Worker(new URL("./mainWorker.js", import.meta.url));
  mainWorker.onmessage = ({ data: { element, message } }) => {
    if (element == "status") {
      if (message == "running") {
        statusElem.dispatchEvent(setStatusRunningEvent);
      } else if (message == "finished") {
        statusElem.dispatchEvent(setStatusFinishedEvent);
      }
    } else if (element == "timer") {
      time = message;
      timer.dispatchEvent(setTimerEvent);
    }
  };
  button.onclick = () => {
    console.log("Passing current sort value of", getCurrentSort());
    mainWorker.postMessage({
      data: { currentSort: getCurrentSort(), sortCount: sort_count },
    });
  };
}
myMain();
