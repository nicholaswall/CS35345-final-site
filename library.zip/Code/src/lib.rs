extern crate wasm_bindgen;

use wasm_bindgen::prelude::*;
use std::vec::Vec;

#[cfg(feature = "parallel")]
use rayon::prelude::*;

#[cfg(feature = "parallel")]
pub use wasm_bindgen_rayon::init_thread_pool;

#[wasm_bindgen]
extern "C" {
    #[wasm_bindgen(js_namespace = console)]
    fn log(s: &str);
}

#[wasm_bindgen]
pub fn bubble_sort(arr: &mut [i16]) {
    for i in 0..arr.len() {
        for j in 0..arr.len() - 1 - i {
            if arr[j] > arr[j + 1] {
                arr.swap(j, j + 1);
            }
        }
    }
}

#[wasm_bindgen]
pub fn insertion_sort(arr: &mut [i16]) {
    for i in 1..arr.len() {
        let mut n = i;
        while n > 0 && &arr[n] < &arr[n-1] {
            arr.swap(n, n-1);
            n -=1;
        }
    }
}

fn partition_par(arr: &mut [i16]) -> usize  {
    arr.swap(0,arr.len() / 2);
    let mut mid = 0;
    for i in 1..arr.len() {
        if &arr[i] < &arr[0] {
            mid += 1;
            arr.swap(i, mid);
        }
    }
    arr.swap(0, mid);
    mid
}

#[wasm_bindgen]
pub fn quicksort(arr: &mut [i16]) { 
    if arr.len() > 30 {
        let mut mid = partition_par(arr);
        if mid < arr.len() / 2 {
            mid += 1;
        }
        let (left, right) = arr.split_at_mut(mid);
        quicksort(left);
        quicksort(right);
    } else {
        insertion_sort(arr);
    }
}


#[wasm_bindgen]
pub fn parallel_quicksort(arr: &mut [i16])
{
    if arr.len() > 30 {
        let mut mid = partition_par(arr);
        if mid < arr.len() / 2 {
            mid += 1;
        }
        let (left, right) = arr.split_at_mut(mid);

        #[cfg(feature = "rayon")]
        if right.len() > 25_000 {
            rayon::join(
                || parallel_quicksort(left),
                || parallel_quicksort(right),
            );
        } 
        else {
            quicksort(left);
            quicksort(right);
        }

        #[cfg(not(feature = "rayon"))]
        {
            quicksort(left);
            quicksort(right);
        }
    } else {
        insertion_sort(arr);
    }
}

fn merge(left_arr: &[i16], right_arr: &[i16], ret: &mut [i16]) {
    let mut left = 0; 
    let mut right = 0;
    let mut index = 0;

    while left < left_arr.len() && right < right_arr.len() {
        if left_arr[left] <= right_arr[right] {
            ret[index] = left_arr[left];
            index += 1;
            left += 1;
        } else {
            ret[index] = right_arr[right];
            index += 1;
            right += 1;
        }
    }

    if left < left_arr.len() {
        ret[index..].copy_from_slice(&left_arr[left..]);
    }
    if right < right_arr.len() {
        ret[index..].copy_from_slice(&right_arr[right..]);
    }
}

#[wasm_bindgen]
pub fn mergesort(arr: &mut [i16]) {
    let mid = arr.len() / 2;
    if mid == 0 {
        return;
    }

    mergesort(&mut arr[..mid]);
    mergesort(&mut arr[mid..]);

    let mut ret = arr.to_vec();

    merge(&arr[..mid], &arr[mid..], &mut ret[..]);

    arr.copy_from_slice(&ret);
}

#[wasm_bindgen]
pub fn selection_sort(arr: &mut [i16]) {
    for i in 0..arr.len() {
        let mut small = i;
        for j in (i + 1)..arr.len() {
          if arr[j] < arr[small] {
            small = j;
          }
        }
        arr.swap(small, i);
    }
}


#[wasm_bindgen]
pub fn parallel_merge_sort(arr: &mut [i16])
{

    let mid = arr.len() / 2;
    if mid == 0 {
        return;
    }

    let (left, right) = arr.split_at_mut(mid);
    let size = left.len() + right.len();
  
    #[cfg(feature = "rayon")]
    if right.len() > 25_000 {
        rayon::join(
            || parallel_merge_sort(left),
            || parallel_merge_sort(right),
        );
    } else {
        mergesort( left);
        mergesort( right);
    }
    #[cfg(not(feature = "rayon"))]
    {
        mergesort(left);
        mergesort(right);
    }

    let mut ret: Vec<i16> =  vec![0; size as usize];

    merge(&left, &right, &mut ret[..]);

    arr.copy_from_slice(&ret);
}