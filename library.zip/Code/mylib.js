import { startWorkers } from './snippets/wasm-bindgen-rayon-7afa899f36665473/src/workerHelpers.js';

let wasm;

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });

cachedTextDecoder.decode();

let cachegetUint8Memory0 = null;
function getUint8Memory0() {
    if (cachegetUint8Memory0 === null || cachegetUint8Memory0.buffer !== wasm.memory.buffer) {
        cachegetUint8Memory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachegetUint8Memory0;
}

function getStringFromWasm0(ptr, len) {
    return cachedTextDecoder.decode(getUint8Memory0().slice(ptr, ptr + len));
}

const heap = new Array(32).fill(undefined);

heap.push(undefined, null, true, false);

let heap_next = heap.length;

function addHeapObject(obj) {
    if (heap_next === heap.length) heap.push(heap.length + 1);
    const idx = heap_next;
    heap_next = heap[idx];

    heap[idx] = obj;
    return idx;
}

let cachegetUint16Memory0 = null;
function getUint16Memory0() {
    if (cachegetUint16Memory0 === null || cachegetUint16Memory0.buffer !== wasm.memory.buffer) {
        cachegetUint16Memory0 = new Uint16Array(wasm.memory.buffer);
    }
    return cachegetUint16Memory0;
}

let WASM_VECTOR_LEN = 0;

function passArray16ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 2);
    getUint16Memory0().set(arg, ptr / 2);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

let cachegetInt16Memory0 = null;
function getInt16Memory0() {
    if (cachegetInt16Memory0 === null || cachegetInt16Memory0.buffer !== wasm.memory.buffer) {
        cachegetInt16Memory0 = new Int16Array(wasm.memory.buffer);
    }
    return cachegetInt16Memory0;
}
/**
* @param {Int16Array} arr
*/
export function bubble_sort(arr) {
    try {
        var ptr0 = passArray16ToWasm0(arr, wasm.__wbindgen_malloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.bubble_sort(ptr0, len0);
    } finally {
        arr.set(getInt16Memory0().subarray(ptr0 / 2, ptr0 / 2 + len0));
        wasm.__wbindgen_free(ptr0, len0 * 2);
    }
}

/**
* @param {Int16Array} d
*/
export function insertion_sort(d) {
    try {
        var ptr0 = passArray16ToWasm0(d, wasm.__wbindgen_malloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.insertion_sort(ptr0, len0);
    } finally {
        d.set(getInt16Memory0().subarray(ptr0 / 2, ptr0 / 2 + len0));
        wasm.__wbindgen_free(ptr0, len0 * 2);
    }
}

/**
* @param {Int16Array} d
*/
export function quicksort(d) {
    try {
        var ptr0 = passArray16ToWasm0(d, wasm.__wbindgen_malloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.quicksort(ptr0, len0);
    } finally {
        d.set(getInt16Memory0().subarray(ptr0 / 2, ptr0 / 2 + len0));
        wasm.__wbindgen_free(ptr0, len0 * 2);
    }
}

/**
* @param {Int16Array} d
*/
export function parallel_quicksort(d) {
    try {
        var ptr0 = passArray16ToWasm0(d, wasm.__wbindgen_malloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.parallel_quicksort(ptr0, len0);
    } finally {
        d.set(getInt16Memory0().subarray(ptr0 / 2, ptr0 / 2 + len0));
        wasm.__wbindgen_free(ptr0, len0 * 2);
    }
}

/**
* @param {Int16Array} arr
*/
export function mergesort(arr) {
    try {
        var ptr0 = passArray16ToWasm0(arr, wasm.__wbindgen_malloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.mergesort(ptr0, len0);
    } finally {
        arr.set(getInt16Memory0().subarray(ptr0 / 2, ptr0 / 2 + len0));
        wasm.__wbindgen_free(ptr0, len0 * 2);
    }
}

/**
* @param {Int16Array} arr
*/
export function selection_sort(arr) {
    try {
        var ptr0 = passArray16ToWasm0(arr, wasm.__wbindgen_malloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.selection_sort(ptr0, len0);
    } finally {
        arr.set(getInt16Memory0().subarray(ptr0 / 2, ptr0 / 2 + len0));
        wasm.__wbindgen_free(ptr0, len0 * 2);
    }
}

/**
* @param {Int16Array} arr
*/
export function parallel_merge_sort(arr) {
    try {
        var ptr0 = passArray16ToWasm0(arr, wasm.__wbindgen_malloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.parallel_merge_sort(ptr0, len0);
    } finally {
        arr.set(getInt16Memory0().subarray(ptr0 / 2, ptr0 / 2 + len0));
        wasm.__wbindgen_free(ptr0, len0 * 2);
    }
}

function getObject(idx) { return heap[idx]; }

function dropObject(idx) {
    if (idx < 36) return;
    heap[idx] = heap_next;
    heap_next = idx;
}

function takeObject(idx) {
    const ret = getObject(idx);
    dropObject(idx);
    return ret;
}
/**
* @param {number} num_threads
* @returns {Promise<any>}
*/
export function initThreadPool(num_threads) {
    var ret = wasm.initThreadPool(num_threads);
    return takeObject(ret);
}

/**
* @param {number} receiver
*/
export function wbg_rayon_start_worker(receiver) {
    wasm.wbg_rayon_start_worker(receiver);
}

/**
*/
export class wbg_rayon_PoolBuilder {

    static __wrap(ptr) {
        const obj = Object.create(wbg_rayon_PoolBuilder.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wbg_rayon_poolbuilder_free(ptr);
    }
    /**
    * @returns {number}
    */
    numThreads() {
        var ret = wasm.wbg_rayon_poolbuilder_numThreads(this.ptr);
        return ret >>> 0;
    }
    /**
    * @returns {number}
    */
    receiver() {
        var ret = wasm.wbg_rayon_poolbuilder_receiver(this.ptr);
        return ret;
    }
    /**
    */
    build() {
        wasm.wbg_rayon_poolbuilder_build(this.ptr);
    }
}

async function load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);

            } catch (e) {
                if (module.headers.get('Content-Type') != 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else {
                    throw e;
                }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);

    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };

        } else {
            return instance;
        }
    }
}

async function init(input, maybe_memory) {
    if (typeof input === 'undefined') {
        input = new URL('mylib_bg.wasm', import.meta.url);
    }
    const imports = {};
    imports.wbg = {};
    imports.wbg.__wbindgen_throw = function(arg0, arg1) {
        throw new Error(getStringFromWasm0(arg0, arg1));
    };
    imports.wbg.__wbindgen_module = function() {
        var ret = init.__wbindgen_wasm_module;
        return addHeapObject(ret);
    };
    imports.wbg.__wbindgen_memory = function() {
        var ret = wasm.memory;
        return addHeapObject(ret);
    };
    imports.wbg.__wbg_startWorkers_04f63eca19916b8f = function(arg0, arg1, arg2) {
        var ret = startWorkers(takeObject(arg0), takeObject(arg1), wbg_rayon_PoolBuilder.__wrap(arg2));
        return addHeapObject(ret);
    };

    if (typeof input === 'string' || (typeof Request === 'function' && input instanceof Request) || (typeof URL === 'function' && input instanceof URL)) {
        input = fetch(input);
    }

    imports.wbg.memory = maybe_memory || new WebAssembly.Memory({initial:17,maximum:16384,shared:true});

    const { instance, module } = await load(await input, imports);

    wasm = instance.exports;
    init.__wbindgen_wasm_module = module;
    wasm.__wbindgen_start();
    return wasm;
}

export default init;

