#!/bin/bash
cargo run --bin mybin --target x86_64-unknown-linux-gnu --release