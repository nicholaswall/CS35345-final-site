/* tslint:disable */
/* eslint-disable */
export function bubble_sort(a: number, b: number): void;
export function insertion_sort(a: number, b: number): void;
export function quicksort(a: number, b: number): void;
export function parallel_quicksort(a: number, b: number): void;
export function mergesort(a: number, b: number): void;
export function selection_sort(a: number, b: number): void;
export function parallel_merge_sort(a: number, b: number): void;
export function __wbg_wbg_rayon_poolbuilder_free(a: number): void;
export function wbg_rayon_poolbuilder_numThreads(a: number): number;
export function wbg_rayon_poolbuilder_receiver(a: number): number;
export function wbg_rayon_poolbuilder_build(a: number): void;
export function initThreadPool(a: number): number;
export function wbg_rayon_start_worker(a: number): void;
export const memory: WebAssembly.Memory;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_free(a: number, b: number): void;
export function __wbindgen_start(): void;
