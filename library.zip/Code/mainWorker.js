let initOutput;

import init, {
  initThreadPool,
  mergesort,
  parallel_merge_sort,
  parallel_quicksort,
  quicksort,
} from "./pkg-parallel/mylib";

init().then((output) => {
  initThreadPool(2).then(() => {
    console.log("Loaded!");
  });
  initOutput = output;
  console.log("Initialized WASM with", initOutput);
});

const MAX_INT_SIZE = 65535;
let sort_size = 50_000;

function generateRandomNumbers(numToSort = sort_size) {
  let data = [];
  for (var i = 0; i < numToSort; i++) {
    data.push(getRandomInt(MAX_INT_SIZE));
  }
  return data;
}

function getRandomInt(max) {
  return Math.floor(Math.random() * max);
}

function isSorted(data) {
  for (var i = 0; i < data.length - 1; i++) {
    if (data[i] > data[i + 1]) return false;
  }
  return true;
}

onmessage = ({ data }) => {
  console.log("This is from the main worker!");

  console.log("TESTING SORT: ----------------------");
  let currentSort = data.data.currentSort;
  let numToSort = data.data.sortCount;
  let input = new Int16Array(generateRandomNumbers(numToSort));
  console.log("Going to sort the following input:", input);
  postMessage({ element: "status", message: "running" });
  const start = performance.now();
  console.log("Recieved input sort method:", currentSort);
  console.log("Recieved input sort count:", numToSort);
  switch (currentSort) {
    case "quicksort":
      console.log("Running quicksort");
      quicksort(input);
      break;
    case "parallel quicksort":
      console.log("Running parallel quicksort");
      parallel_quicksort(input);
      break;
    case "merge sort":
      console.log("Running mergesort");
      mergesort(input);
      break;
    case "parallel merge sort":
      console.log("Running parallel merge sort");
      parallel_merge_sort(input);
      break;
    default:
      console.log("Running quicksort");
      quicksort(input);
      break;
  }

  const end = performance.now();
  let time = end - start;
  console.log("Took:", time);

  postMessage({ element: "status", message: "finished" });
  postMessage({ element: "timer", message: time });

  console.log("The sorted output is: ", input);
  console.log("Is Sorted:", isSorted(input));
  console.log("SORT FINISHED: -----------------------");
};
